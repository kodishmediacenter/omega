# -*- coding: cp1252 -*-
import xbmc
import xbmcgui
import webbrowser


    
dialog = xbmcgui.Dialog()
ret2 = dialog.select('[COLOR green][B]Melhores Ra[/B][/COLOR][COLOR red][B]dios Portuguesas Top[/B][/COLOR]', ['RFM','RFM Dance Floor','RFM Oceano pacifico','RFM Rock','RFM 80s','Radio Renascen�a','Mega Hits','Antena 1','M80','M80 Rock','M80 Baladas','RVE','Fado de Coimbra','Klassik Radio','Klara Continuo','Radio K7','Heart 80s','Classic Metal Radio','Totally Radio 80s','La Grosse Raggae','Ambi Nature Radio','Loca Fm','Zen Calm Radio','100hitz - New Country','Classic Coutry','','Pagina 2 [Em Breve]'])

if ret2 == 0:
    link = "https://21313.live.streamtheworld.com/RFMAAC.aac"
    xbmc.Player().play(""+link+"")

if ret2 == 1:
    link = "https://20873.live.streamtheworld.com/DANCEONTHEFLOORAAC.aac"
    xbmc.Player().play(""+link+"")

if ret2 == 2:
    link = "https://23603.live.streamtheworld.com/OCEANPACIFICAAC.aac"
    xbmc.Player().play(""+link+"")

if ret2 == 3:
    link = "https://20873.live.streamtheworld.com/RFMONTHEROCKAAC.aac"
    xbmc.Player().play(""+link+"")

if ret2 == 4:
    link = "https://20133.live.streamtheworld.com/GR80SRFMAAC.aac"
    xbmc.Player().play(""+link+"")

if ret2 == 5:
    link = "https://22713.live.streamtheworld.com/RADIO_RENASCENCAAAC.aac"
    xbmc.Player().play(""+link+"")

if ret2 == 6:
    link = "https://21313.live.streamtheworld.com/MEGA_HITSAAC.aac"
    xbmc.Player().play(""+link+"")

if ret2 == 7:
    link = "http://radiocast.rtp.pt/antena180a.mp3"
    xbmc.Player().play(""+link+"")

if ret2 == 8:
    link = "http://195.23.102.207/m80"
    xbmc.Player().play(""+link+"")
    
if ret2 == 9:
    link = "https://mcrwowza8.mcr.iol.pt/m80rock/m80rock.stream/media_w1655596674_481441.aac"
    xbmc.Player().play(""+link+"")
    
if ret2 == 10:
    link = "https://mcrwowza7.mcr.iol.pt/m80ballads/m80ballads.stream/media_w939594193_481562.aac"
    xbmc.Player().play(""+link+"")
    
if ret2 == 11:
    link = "http://radios.dotsi.pt:8001/stream"
    xbmc.Player().play(""+link+"")
    
if ret2 == 12:
    link = "https://nl.digitalrm.pt:8048/stream"
    xbmc.Player().play(""+link+"")

if ret2 == 13:
    link = "https://klassikr.streamabc.net/klassikradio-simulcast-mp3-mq?amsparams=playerid%3A7Digital&sABC=5s841or0%230%23q93n3663p9rso718798r52950313os03%237Qvtvgny"
    xbmc.Player().play(""+link+"")

if ret2 == 14:
    link = "http://icecast.vrtcdn.be/klaracontinuo-high.mp3"
    xbmc.Player().play(""+link+"")

if ret2 == 15:
    link = "http://rlcbdance.no-ip.org:8100/;"
    xbmc.Player().play(""+link+"")
    
if ret2 == 16:
    link = "http://media-ice.musicradio.com/Heart80sMP3"
    xbmc.Player().play(""+link+"")

if ret2 == 17:
    link = "http://hazel.torontocast.com:2280/stream"
    xbmc.Player().play(""+link+"")

if ret2 == 18:
    link = "https://14933.live.streamtheworld.com/T_RAD_80S_S01_SC"
    xbmc.Player().play(""+link+"")
if ret2 == 19:
    link = "http://hd.lagrosseradio.info/lagrosseradio-reggae-192.mp3?listen.pls"
    xbmc.Player().play(""+link+"")
if ret2 == 20:
    link = "http://hubble.shoutca.st:8067/;"
    xbmc.Player().play(""+link+"")
if ret2 == 21:
    link = "http://s02.fjperezdj.com:8036/live"
    xbmc.Player().play(""+link+"")
if ret2 == 22:
    link = "http://streams.calmradio.com:14028/stream/1/"
    xbmc.Player().play(""+link+"")
if ret2 == 23:
    link = "http://206.217.213.236:9210/"
    xbmc.Player().play(""+link+"")
if ret2 == 24:
    link = "http://198.105.216.204:8194/;"
    xbmc.Player().play(""+link+"")






if ret2 == 25:
    dialog = xbmcgui.Dialog()
    link5 = dialog.select('[COLOR yellow][B]Melhores Radios Top[/B][/COLOR]', ['','','','','','Pagina 2'])
    
